---
title: Featured slider 1
---

This is Featured slider 1 component

### Picture styles:

- Normal: 768x500

- Tablet: 1024x500

- Desktop: 1400x500
