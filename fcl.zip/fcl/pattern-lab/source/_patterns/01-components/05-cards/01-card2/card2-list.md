---
title: card2
---

This is card 2 component

### Image style: 960x540
