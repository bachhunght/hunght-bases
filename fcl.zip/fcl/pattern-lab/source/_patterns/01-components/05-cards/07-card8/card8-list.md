---
title: card8
---

This is card 8 component

### Picture styles:

- Normal: 768x820

- Tablet: 1400x495
