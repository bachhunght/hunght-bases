---
title: card7
---

This is card 7 component

### Image style: 320x320
