---
title: CTA4
---

This is call to action 4 component

### Picture styles:

- Normal: 768x410

- Tablet: 512x410

- Desktop: 700x410
