---
title: CTA2
---

This is call to action 2 component

### Picture styles:

- Normal: 768x420

- Tablet: 1400x420
