---
title: Quote 4
---

This is quote 4 component

### Picture styles:

- Normal: 160x160