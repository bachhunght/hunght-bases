---
title: Quote 2
---

This is quote 2 component
