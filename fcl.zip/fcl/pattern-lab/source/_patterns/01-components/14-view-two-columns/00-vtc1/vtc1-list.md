---
title: View two columns 1
---

This is View two columns 1 component

