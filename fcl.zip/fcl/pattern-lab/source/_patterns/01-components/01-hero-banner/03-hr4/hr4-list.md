---
title: HR4
---

This is hero banner 4 component

### Picture styles:

- Normal: 768x820

- Tablet: 1400x665
