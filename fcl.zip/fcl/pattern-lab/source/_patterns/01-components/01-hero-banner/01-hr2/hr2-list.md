---
title: HR2
---

This is hero banner 2 component

### Picture styles:

- Normal: 768x820

- Tablet: 1400x665
