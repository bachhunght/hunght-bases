---
title: HR1
---

This is hero banner 1 component

### Picture styles:

- Normal: 768x820

- Tablet: 1400x665
