---
title: HR3
---

This is hero banner 3 component

### Picture styles:

- Normal: 768x820

- Tablet: 1400x665
