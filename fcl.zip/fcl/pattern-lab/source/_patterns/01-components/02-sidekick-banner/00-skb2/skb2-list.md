---
title: SKB 2
---

This is sidekick banner 2 component

### Picture styles:

- Normal: 768x430

- Tablet: 1024x350

- Desktop: 1400x350
