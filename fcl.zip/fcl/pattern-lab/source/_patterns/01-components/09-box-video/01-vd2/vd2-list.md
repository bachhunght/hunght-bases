---
title: Box video 2
---

This is box video 2 component

### Image styles: 960x540
