---
title: Image feature 2
---

This is image feature 2 component

### Picture styles:

- Normal: 768x395

- Tablet: 1024x527

- Desktop: 1400x720
