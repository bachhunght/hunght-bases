---
title: Image feature 3
---

This is image feature 3 component

### Picture styles:

- Normal: 768x373

- Tablet: 1024x497

- Desktop: 1400x680
