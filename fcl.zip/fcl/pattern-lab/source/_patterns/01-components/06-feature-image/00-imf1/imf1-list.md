---
title: Image feature 1
---

This is image feature 1 component

### Picture styles:

- Normal: 768x370

- Tablet: 1024x494

- Desktop: 1400x680
