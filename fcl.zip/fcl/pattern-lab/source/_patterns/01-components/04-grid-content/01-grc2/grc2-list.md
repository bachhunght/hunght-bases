---
title: Grid Content 2
---

This is Grid Content 2 component

Picture 1:
- Normal: 200x200
- Desktop: 250x202