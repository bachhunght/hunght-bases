---
title: Grid Content 4
---

This is Grid Content 4 component

### Picture styles:

- Normal: 768x433

- Tablet: 512x288
