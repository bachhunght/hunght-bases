---
title: Grid image 2
---

This is Grid image 2 component

### Picture styles:

- Normal: 960x540
- Small: 480x270