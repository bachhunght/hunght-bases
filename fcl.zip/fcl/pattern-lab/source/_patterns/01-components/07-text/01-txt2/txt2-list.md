---
title: Text 2
---

This is text 2 component

### Picture styles:

- Normal: 768x432

- Tablet: 1024x350

- Desktop: 1400x350
